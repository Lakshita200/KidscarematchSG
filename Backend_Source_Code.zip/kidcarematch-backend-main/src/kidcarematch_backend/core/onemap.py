"""OneMap geospatial adapter for coordinate resolution, caching, detour routing, and dynamic authentication (ADR-0007, ADR-0008, Ticket #70, Ticket #74)."""

import logging
import math
import threading
import time
from collections.abc import Sequence
from datetime import datetime, timezone
from typing import Any, NamedTuple

import httpx
from sqlmodel import Session, col, select

from kidcarematch_backend.core.config import settings
from kidcarematch_backend.core.route_cache import BoundedTTLCacheWithCoalescing
from kidcarematch_backend.db.db import PostalCoordinateCache

logger = logging.getLogger(__name__)

STAGE1_MAX_CANDIDATES = 15
EARTH_RADIUS_KM = 6371.0
AVERAGE_TRANSIT_SPEED_KMH = 25.0


class OneMapTokenManager:
    """Thread-safe in-memory manager for OneMap Service Account access tokens.

    Supports:
    - Double-checked locking with threading.RLock for multi-threaded concurrency safety.
    - Dynamic acquisition via OneMap Auth API (/api/auth/post/getToken).
    - Proactive refresh within 300 seconds of token expiration.
    - Resilient parsing of Unix epoch timestamps with fallback to 72 hours.
    - Fallback to static ONEMAP_API_TOKEN if service account credentials are not configured.
    - Explicit token invalidation for reactive 401 handling.
    """

    DEFAULT_EXPIRY_HOURS: float = 72.0
    REFRESH_BUFFER_SECS: float = 300.0

    def __init__(self) -> None:
        self._token: str | None = None
        self._expiry_timestamp: float | None = None
        self._lock = threading.RLock()

    @property
    def token(self) -> str | None:
        """Return currently cached access token string or None."""
        return self._token

    @property
    def expiry_timestamp(self) -> float | None:
        """Return currently cached expiration timestamp (Unix epoch float) or None."""
        return self._expiry_timestamp

    def _is_token_valid(self, now: float) -> bool:
        """Check if cached token is present and not within the 300-second proactive expiration buffer."""
        if self._token is None or self._expiry_timestamp is None:
            return False
        return now < (self._expiry_timestamp - self.REFRESH_BUFFER_SECS)

    @staticmethod
    def _parse_expiry_timestamp(raw_expiry: Any, now: float) -> float:
        """Parse raw expiry timestamp (int, float, numeric string) with 72h default fallback."""
        default_expiry = now + OneMapTokenManager.DEFAULT_EXPIRY_HOURS * 3600.0
        if raw_expiry is None:
            return default_expiry

        try:
            if isinstance(raw_expiry, (int, float)):
                parsed = float(raw_expiry)
            elif isinstance(raw_expiry, str):
                parsed = float(raw_expiry.strip())
            else:
                return default_expiry
        except (ValueError, TypeError):
            return default_expiry

        if math.isnan(parsed) or math.isinf(parsed) or parsed <= now:
            return default_expiry

        return parsed

    def probe_token_health(
        self, client: httpx.Client | None = None
    ) -> tuple[bool, str | None]:
        """Perform diagnostic health check of OneMap authentication.

        - If credentials are not configured, returns (True, None).
        - If cached token is valid, returns (True, None).
        - When credentials configured: attempts token acquisition without swallowing diagnostic errors.
          If HTTP response status code is not 200 or network error occurs, captures the actual status
          code or error details and returns (False, err_msg).
        - When token acquired successfully, stores in cache and returns (True, None).
        """
        if not settings.ONEMAP_EMAIL or not settings.ONEMAP_PASSWORD:
            return True, None

        now = time.time()
        if self._is_token_valid(now):
            return True, None

        with self._lock:
            now = time.time()
            if self._is_token_valid(now):
                return True, None

            email = settings.ONEMAP_EMAIL
            password = settings.ONEMAP_PASSWORD
            if not email or not password:
                return True, None

            payload = {"email": email, "password": password}
            try:
                if client is not None:
                    response = client.post(
                        settings.ONEMAP_AUTH_URL,
                        json=payload,
                        headers={"Content-Type": "application/json"},
                        timeout=5.0,
                    )
                else:
                    with httpx.Client(timeout=5.0) as http_client:
                        response = http_client.post(
                            settings.ONEMAP_AUTH_URL,
                            json=payload,
                            headers={"Content-Type": "application/json"},
                        )

                if response.status_code != 200:
                    text_snippet = (
                        response.text[:200]
                        if hasattr(response, "text") and response.text
                        else ""
                    )
                    detail = (
                        f"HTTP {response.status_code} - {text_snippet}"
                        if text_snippet
                        else f"HTTP {response.status_code}"
                    )
                    return False, f"OneMap authentication failed: {detail}"

                data = response.json()
                if not isinstance(data, dict):
                    return (
                        False,
                        f"OneMap authentication failed: Unexpected response payload type {type(data)}",
                    )

                token = data.get("access_token") or data.get("accessToken")
                if not token or not isinstance(token, str):
                    return (
                        False,
                        f"OneMap authentication failed: Missing valid access_token in response: {data}",
                    )

                raw_expiry = data.get("expiry_timestamp") or data.get("expiryTimestamp")
                self._token = token
                self._expiry_timestamp = self._parse_expiry_timestamp(raw_expiry, now)
                return True, None

            except httpx.HTTPStatusError as exc:
                status_code = (
                    exc.response.status_code if exc.response is not None else "unknown"
                )
                text_snippet = (
                    exc.response.text[:200]
                    if exc.response is not None
                    and hasattr(exc.response, "text")
                    and exc.response.text
                    else ""
                )
                detail = (
                    f"HTTP {status_code} - {text_snippet}"
                    if text_snippet
                    else f"HTTP {status_code}"
                )
                return False, f"OneMap authentication failed: {detail}"
            except (
                httpx.HTTPError,
                httpx.TimeoutException,
                ValueError,
                KeyError,
                OSError,
                TypeError,
                AttributeError,
            ) as exc:
                return False, f"OneMap authentication failed: {exc}"

    def get_valid_token(self, client: httpx.Client | None = None) -> str | None:
        """Return a valid OneMap access token, fetching or refreshing if necessary.

        Thread-safe via double-checked locking with re-entrant lock (RLock).
        """
        now = time.time()
        # Fast path outside lock
        if self._is_token_valid(now):
            return self._token

        if not settings.ONEMAP_EMAIL or not settings.ONEMAP_PASSWORD:
            return settings.ONEMAP_API_TOKEN

        ok, err = self.probe_token_health(client=client)
        if ok and self._token:
            return self._token

        if err:
            logger.warning(
                "OneMap token acquisition failed from %s: %s",
                settings.ONEMAP_AUTH_URL,
                err,
            )
        return settings.ONEMAP_API_TOKEN

    def invalidate_token(self) -> None:
        """Clear cached access token and expiration timestamp under lock."""
        with self._lock:
            self._token = None
            self._expiry_timestamp = None

    def get_auth_headers(self, client: httpx.Client | None = None) -> dict[str, str]:
        """Return Authorization Bearer header dictionary if a valid token is available, else empty dict."""
        token = self.get_valid_token(client=client)
        if token:
            clean = token.removeprefix("Bearer ").strip()
            return {"Authorization": f"Bearer {clean}"}
        return {}


onemap_token_manager = OneMapTokenManager()


def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate great-circle straight-line distance between two coordinates in kilometers."""
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (
        math.sin(delta_phi / 2.0) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2.0) ** 2
    )
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return round(EARTH_RADIUS_KM * c, 3)


def estimate_transit_duration_mins(distance_km: float) -> float:
    """Estimate public transit commute travel duration in minutes based on straight-line distance."""
    if distance_km <= 0.0:
        return 0.0
    duration_mins = (distance_km / AVERAGE_TRANSIT_SPEED_KMH) * 60.0
    return max(1.0, round(duration_mins, 1))


def _fetch_onemap(
    url: str,
    params: dict[str, str | int],
    client: httpx.Client,
) -> httpx.Response:
    """Execute OneMap API call with dynamic auth headers and reactive 401 retry."""
    headers = onemap_token_manager.get_auth_headers(client=client)
    response = client.get(url, params=params, headers=headers, timeout=5.0)
    if response.status_code == 401:
        onemap_token_manager.invalidate_token()
        retry_headers = onemap_token_manager.get_auth_headers(client=client)
        response = client.get(url, params=params, headers=retry_headers, timeout=5.0)
    return response


def _warm_commute_postal_if_verified(postal: str, lat: float, lng: float) -> None:
    try:
        from kidcarematch_backend.core.commute import warm_verified_postal_from_db

        warm_verified_postal_from_db(postal, lat, lng)
    except ImportError:
        pass


def _set_commute_postal_verified(postal: str, lat: float, lng: float) -> None:
    try:
        from kidcarematch_backend.core.commute import set_verified_postal

        set_verified_postal(postal, lat, lng)
    except ImportError:
        pass


def resolve_postal_coordinates(
    postal: str | None,
    session: Session,
    client: httpx.Client | None = None,
) -> tuple[float, float] | None:
    """Resolve a 6-digit Singapore postal code to (latitude, longitude) coordinates.

    Checks persistent database cache (PostalCoordinateCache) first.
    If not cached, queries OneMap search API and persists the resolved coordinates.
    Exact POSTAL matches warm the in-memory commute postal cache and mark it verified.
    """
    if not postal:
        return None
    clean_postal = postal.strip()
    if len(clean_postal) != 6 or not clean_postal.isdigit():
        return None

    # 1. Query persistent database cache
    cached = session.get(PostalCoordinateCache, clean_postal)
    if cached is not None:
        _warm_commute_postal_if_verified(clean_postal, cached.latitude, cached.longitude)
        return cached.latitude, cached.longitude

    # 2. Query external OneMap Search API
    params: dict[str, str | int] = {
        "searchVal": clean_postal,
        "returnGeom": "Y",
        "getAddrDetails": "Y",
        "pageNum": 1,
    }

    try:
        if client is not None:
            response = _fetch_onemap(
                settings.ONEMAP_API_URL, params=params, client=client
            )
        else:
            with httpx.Client(timeout=5.0) as http_client:
                response = _fetch_onemap(
                    settings.ONEMAP_API_URL, params=params, client=http_client
                )

        response.raise_for_status()
        data = response.json()

        if data.get("found", 0) > 0 and data.get("results"):
            results = data["results"]
            exact_match = None
            for item in results:
                if str(item.get("POSTAL") or "").strip() == clean_postal:
                    exact_match = item
                    break

            selected = exact_match if exact_match is not None else results[0]
            lat = float(selected["LATITUDE"])
            lon = float(selected["LONGITUDE"])
            x_val = (
                float(selected["X"])
                if selected.get("X") and str(selected["X"]).upper() != "NIL"
                else None
            )
            y_val = (
                float(selected["Y"])
                if selected.get("Y") and str(selected["Y"]).upper() != "NIL"
                else None
            )
            address = selected.get("ADDRESS")

            cache_entry = PostalCoordinateCache(
                postal_code=clean_postal,
                latitude=lat,
                longitude=lon,
                x_coord=x_val,
                y_coord=y_val,
                address=address,
            )
            session.add(cache_entry)
            session.commit()
            session.refresh(cache_entry)

            if (
                exact_match is not None
                and math.isfinite(lat)
                and math.isfinite(lon)
                and -90 <= lat <= 90
                and -180 <= lon <= 180
            ):
                _set_commute_postal_verified(clean_postal, lat, lon)

            return lat, lon
    except (
        httpx.HTTPError,
        httpx.TimeoutException,
        ValueError,
        KeyError,
        OSError,
    ) as exc:
        logger.warning(
            "Failed to resolve coordinates for postal %s via OneMap: %s",
            clean_postal,
            exc,
        )

    return None


def resolve_coordinates_batch(
    postals: Sequence[str | None],
    session: Session,
    client: httpx.Client | None = None,
) -> dict[str, tuple[float, float]]:
    """Batch resolve coordinates for a list of postal codes, utilizing persistent cache."""
    valid_postals = {
        p.strip() for p in postals if p and len(p.strip()) == 6 and p.strip().isdigit()
    }
    if not valid_postals:
        return {}

    # Query existing records from persistent cache
    cached_records = session.exec(
        select(PostalCoordinateCache).where(
            col(PostalCoordinateCache.postal_code).in_(valid_postals)
        )
    ).all()

    for rec in cached_records:
        _warm_commute_postal_if_verified(rec.postal_code, rec.latitude, rec.longitude)

    result_map: dict[str, tuple[float, float]] = {
        rec.postal_code: (rec.latitude, rec.longitude) for rec in cached_records
    }

    # Fetch missing postals
    missing_postals = valid_postals - set(result_map.keys())
    for postal in missing_postals:
        coords = resolve_postal_coordinates(postal, session=session, client=client)
        if coords is not None:
            result_map[postal] = coords

    return result_map


class OneMapRouteKey(NamedTuple):
    start_lat: float
    start_lng: float
    end_lat: float
    end_lng: float


_ONEMAP_ROUTE_CACHE: BoundedTTLCacheWithCoalescing[
    OneMapRouteKey, tuple[float, float]
] = BoundedTTLCacheWithCoalescing(maxsize=1024, ttl=3600.0)


def clear_onemap_route_cache() -> None:
    """Clear bounded in-memory cache of OneMap route calculations."""
    _ONEMAP_ROUTE_CACHE.clear()


def clear_onemap_caches() -> None:
    """Clear all in-memory OneMap caches."""
    clear_onemap_route_cache()


def get_route_duration_and_distance(
    start: tuple[float, float],
    end: tuple[float, float],
    client: httpx.Client | None = None,
) -> tuple[float, float]:
    """Calculate commute route travel duration (minutes) and distance (km) between two coordinates.

    Calls OneMap Public Transport Routing API (`routeType=pt`).
    Results are cached in a thread-safe bounded TTL cache (maxsize=1024, ttl=3600s)
    with concurrent in-flight request coalescing.
    Falls back gracefully to straight-line distance and estimated transit time if external API fails.
    Fallback estimates are never cached so future calls retry OneMap.
    """
    straight_dist_km = haversine_distance_km(start[0], start[1], end[0], end[1])
    if straight_dist_km < 0.001:
        return 0.0, 0.0

    cache_key = OneMapRouteKey(
        start_lat=round(start[0], 6),
        start_lng=round(start[1], 6),
        end_lat=round(end[0], 6),
        end_lng=round(end[1], 6),
    )

    def _compute_route() -> tuple[tuple[float, float], bool]:
        params: dict[str, str | int] = {
            "start": f"{start[0]},{start[1]}",
            "end": f"{end[0]},{end[1]}",
            "routeType": "pt",
            "date": datetime.now(timezone.utc).strftime("%m-%d-%Y"),
            "time": "08:00:00",
            "mode": "transit",
            "maxWalkDistance": 1000,
            "numItineraries": 1,
        }

        try:
            if client is not None:
                response = _fetch_onemap(
                    settings.ONEMAP_ROUTING_API_URL, params=params, client=client
                )
            else:
                with httpx.Client(timeout=5.0) as http_client:
                    response = _fetch_onemap(
                        settings.ONEMAP_ROUTING_API_URL,
                        params=params,
                        client=http_client,
                    )

            response.raise_for_status()
            data = response.json()

            # Parse Public Transport itinerary response
            plan = data.get("plan")
            if plan and plan.get("itineraries"):
                first_itinerary = plan["itineraries"][0]
                duration_secs = first_itinerary.get("duration", 0)
                duration_mins = duration_secs / 60.0
                return (round(duration_mins, 1), round(straight_dist_km, 2)), True

            # Parse Alternative route_summary format
            summary = data.get("route_summary")
            if summary:
                duration_secs = summary.get("total_time", 0)
                dist_meters = summary.get("total_distance", 0)
                return (
                    round(duration_secs / 60.0, 1),
                    round(dist_meters / 1000.0, 2),
                ), True

        except (
            httpx.HTTPError,
            httpx.TimeoutException,
            ValueError,
            KeyError,
            OSError,
        ) as exc:
            logger.warning(
                "OneMap Routing API call failed (%s -> %s), falling back to straight-line: %s",
                start,
                end,
                exc,
            )

        # Graceful fallback: straight-line estimation (NOT cacheable)
        est_duration_mins = estimate_transit_duration_mins(straight_dist_km)
        return (round(est_duration_mins, 1), round(straight_dist_km, 2)), False

    return _ONEMAP_ROUTE_CACHE.get_or_compute(cache_key, _compute_route)


def normalize_travel_fit(deviations: list[float]) -> list[float]:
    """Pool-relative Travel Fit normalization (ADR-0007).

    Travel Fit = 100.0 * (1.0 - (dev - dev_min) / (dev_max - dev_min))
    - If dev_max == dev_min: all candidates receive 100.0%
    - Lowest deviation receives 100.0%
    - Largest deviation receives 0.0%
    - Intermediate candidates scale linearly
    """
    if not deviations:
        return []

    dev_min = min(deviations)
    dev_max = max(deviations)

    if math.isclose(dev_max, dev_min, abs_tol=1e-5):
        return [100.0] * len(deviations)

    spread = dev_max - dev_min
    return [
        round(max(0.0, min(100.0, 100.0 * (1.0 - (dev - dev_min) / spread))), 2)
        for dev in deviations
    ]
