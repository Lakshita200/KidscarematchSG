from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite:///:memory:"
    DB_ECHO: bool = False
    DATA_GOV_SG_API_URL: str = "https://data.gov.sg/api/action/datastore_search"
    DATA_GOV_SG_CENTRES_RESOURCE_ID: str = "d_696c994c50745b079b3684f0e90ffc53"
    DATA_GOV_SG_SERVICES_RESOURCE_ID: str = "d_44cfe12f2858ae503a093dfc075a28be"
    ONEMAP_API_URL: str = "https://www.onemap.gov.sg/api/common/elastic/search"
    ONEMAP_ROUTING_API_URL: str = "https://www.onemap.gov.sg/api/public/routingsvc/route"
    ONEMAP_AUTH_URL: str = "https://www.onemap.gov.sg/api/auth/post/getToken"
    ONEMAP_EMAIL: str | None = None
    ONEMAP_PASSWORD: str | None = None
    ONEMAP_API_TOKEN: str | None = None
    GEMINI_API_KEY: str | None = None
    GEMINI_MODEL: str = "gemini-2.5-flash"
    FIREBASE_PROJECT_ID: str | None = "kidcare-match-sg"
    FIREBASE_CREDENTIALS_PATH: str | None = "./firebase_svc_acc.json"
    CORS_ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "https://kidscare-match-sg.web.app",
        "https://kidscare-match-sg.firebaseapp.com",
        "https://kidcarematch-frontend.vercel.app"
    ]
    COMMUTE_ENABLE_DIRECT_BASELINE: bool = True
    COMMUTE_ENABLE_WEEKDAY_SAMPLING: bool = True
    COMMUTE_CYCLE_SECRET_KEY: str = "kidcarematch-commute-cycle-secret-key-v1"
    COMMUTE_CALL_TIMEOUT_SECONDS: float = 6.0
    COMMUTE_EVALUATION_DEADLINE_SECONDS: float = 12.0
    COMMUTE_MAX_WORKERS: int = 4

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


settings = Settings()
