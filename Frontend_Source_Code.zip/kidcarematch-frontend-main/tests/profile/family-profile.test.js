import { describe, expect, it, vi } from "vitest";
import {
  PROFILE_DEFAULTS,
  WEIGHT_KEYS,
  WEIGHT_LABELS,
  fromApiProfile,
  isProfileComplete,
  nextMonthValue,
  normalizeWeights,
  toApiProfile,
  validateFamilyProfile,
} from "../../src/profile/familyProfile.js";

describe("familyProfile module", () => {
  const buildValidForm = (overrides = {}) => ({
    ...PROFILE_DEFAULTS,
    home: "123456",
    enrolMonth: "2026-12",
    ...overrides,
  });

  describe("validateFamilyProfile and isProfileComplete", () => {
    it("accepts a valid defaulted form with 6-digit home postcode and valid enrolment month", () => {
      const form = buildValidForm();
      const errors = validateFamilyProfile(form);
      expect(errors).toEqual([]);
      expect(isProfileComplete(form)).toBe(true);
    });

    it("rejects missing or malformed home postal codes", () => {
      expect(validateFamilyProfile(buildValidForm({ home: "" }))).toContain(
        "Enter your 6-digit home postal code."
      );
      expect(validateFamilyProfile(buildValidForm({ home: "12345" }))).toContain(
        "Enter your 6-digit home postal code."
      );
      expect(validateFamilyProfile(buildValidForm({ home: "1234567" }))).toContain(
        "Enter your 6-digit home postal code."
      );
      expect(validateFamilyProfile(buildValidForm({ home: "abcdef" }))).toContain(
        "Enter your 6-digit home postal code."
      );
    });

    it("rejects missing required child level, citizenship status, or care service", () => {
      expect(validateFamilyProfile(buildValidForm({ level: "" }))).toContain(
        "Select a child level."
      );
      expect(validateFamilyProfile(buildValidForm({ citizenship: "" }))).toContain(
        "Select citizenship status."
      );
      expect(validateFamilyProfile(buildValidForm({ service: "" }))).toContain(
        "Select care service required."
      );
    });

    it("rejects missing or malformed enrolment months", () => {
      expect(validateFamilyProfile(buildValidForm({ enrolMonth: "" }))).toContain(
        "Enter enrolment month in YYYY-MM format."
      );
      expect(validateFamilyProfile(buildValidForm({ enrolMonth: "2026-1" }))).toContain(
        "Enter enrolment month in YYYY-MM format."
      );
      expect(validateFamilyProfile(buildValidForm({ enrolMonth: "2026/12" }))).toContain(
        "Enter enrolment month in YYYY-MM format."
      );
      expect(validateFamilyProfile(buildValidForm({ enrolMonth: "invalid" }))).toContain(
        "Enter enrolment month in YYYY-MM format."
      );
    });

    it("rejects non-positive budgets", () => {
      expect(validateFamilyProfile(buildValidForm({ budget: 0 }))).toContain(
        "Enter a monthly budget."
      );
      expect(validateFamilyProfile(buildValidForm({ budget: -50 }))).toContain(
        "Enter a monthly budget."
      );
      expect(validateFamilyProfile(buildValidForm({ budget: "" }))).toContain(
        "Enter a monthly budget."
      );
      expect(validateFamilyProfile(buildValidForm({ budget: "abc" }))).toContain(
        "Enter a monthly budget."
      );
    });

    it("treats workplace as optional when location preference is HOME", () => {
      const form = buildValidForm({ locationPref: "HOME", work: "" });
      expect(validateFamilyProfile(form)).toEqual([]);
      expect(isProfileComplete(form)).toBe(true);
    });

    it("rejects malformed workplace postal code when provided under HOME preference", () => {
      const form = buildValidForm({ locationPref: "HOME", work: "12345" });
      expect(validateFamilyProfile(form)).toContain(
        "Workplace postal code must be 6 digits."
      );
      expect(isProfileComplete(form)).toBe(false);
    });

    it("requires a 6-digit workplace postal code when location preference is WORKPLACE or EITHER", () => {
      const workplaceMissing = buildValidForm({ locationPref: "WORKPLACE", work: "" });
      expect(validateFamilyProfile(workplaceMissing)).toContain(
        "Add your workplace postal code for this location preference."
      );
      expect(isProfileComplete(workplaceMissing)).toBe(false);

      const eitherMissing = buildValidForm({ locationPref: "EITHER", work: "" });
      expect(validateFamilyProfile(eitherMissing)).toContain(
        "Add your workplace postal code for this location preference."
      );
      expect(isProfileComplete(eitherMissing)).toBe(false);

      const workplaceMalformed = buildValidForm({ locationPref: "WORKPLACE", work: "123" });
      expect(validateFamilyProfile(workplaceMalformed)).toContain(
        "Workplace postal code must be 6 digits."
      );

      const workplaceValid = buildValidForm({ locationPref: "WORKPLACE", work: "654321" });
      expect(validateFamilyProfile(workplaceValid)).toEqual([]);
      expect(isProfileComplete(workplaceValid)).toBe(true);

      const eitherValid = buildValidForm({ locationPref: "EITHER", work: "654321" });
      expect(validateFamilyProfile(eitherValid)).toEqual([]);
      expect(isProfileComplete(eitherValid)).toBe(true);
    });

    it("treats income and members as optional without failing validation", () => {
      const form = buildValidForm({ income: "", members: "" });
      expect(validateFamilyProfile(form)).toEqual([]);
      expect(isProfileComplete(form)).toBe(true);
    });

    it("returns false for isProfileComplete whenever errors exist", () => {
      expect(isProfileComplete(null)).toBe(false);
      expect(isProfileComplete({})).toBe(false);
      expect(isProfileComplete(buildValidForm({ home: "" }))).toBe(false);
    });

    it("does not call OneMap or perform any external network requests", () => {
      const globalFetchSpy = vi.fn();
      vi.stubGlobal("fetch", globalFetchSpy);
      try {
        validateFamilyProfile(buildValidForm());
        expect(globalFetchSpy).not.toHaveBeenCalled();
      } finally {
        vi.unstubAllGlobals();
      }
    });
  });

  describe("toApiProfile", () => {
    it("serialises independent integer ratings without normalization", () => {
      const form = buildValidForm({
        weights: { vacancy: 5, cost: 5, travel: 1 },
      });
      const apiPayload = toApiProfile(form);
      expect(apiPayload).toMatchObject({ vacancy_weight: 5, cost_weight: 5, travel_weight: 1 });
    });

    it("preserves equal low and high ratings as distinct choices", () => {
      expect(toApiProfile(buildValidForm({ weights: { vacancy: 1, cost: 1, travel: 1 } })))
        .toMatchObject({ vacancy_weight: 1, cost_weight: 1, travel_weight: 1 });
      expect(toApiProfile(buildValidForm({ weights: { vacancy: 5, cost: 5, travel: 5 } })))
        .toMatchObject({ vacancy_weight: 5, cost_weight: 5, travel_weight: 5 });
    });

    it("preserves an explicitly passed profileName or form profile_name", () => {
      const form = buildValidForm({ profile_name: "Form Profile Name" });
      const apiPayloadDefault = toApiProfile(form);
      expect(apiPayloadDefault.profile_name).toBe("Form Profile Name");

      const apiPayloadExplicit = toApiProfile(form, "Custom Preserved Name");
      expect(apiPayloadExplicit.profile_name).toBe("Custom Preserved Name");
    });

    it("defaults profile_name to 'My family profile' when no name is provided", () => {
      const form = buildValidForm();
      delete form.profile_name;
      delete form.profileName;
      const apiPayload = toApiProfile(form);
      expect(apiPayload.profile_name).toBe("My family profile");
    });

    it("maps blank optional income to 0 and blank optional members to 1", () => {
      const form = buildValidForm({ income: "", members: "" });
      const apiPayload = toApiProfile(form);
      expect(apiPayload.household_income).toBe(0);
      expect(apiPayload.household_member_count).toBe(1);
    });

    it("maps workplace postal code to null when empty, and retains it when set", () => {
      const formNoWork = buildValidForm({ work: "" });
      expect(toApiProfile(formNoWork).workplace_postal_code).toBeNull();

      const formWithWork = buildValidForm({ work: "654321" });
      expect(toApiProfile(formWithWork).workplace_postal_code).toBe("654321");
    });

    it("maps backend schema field names correctly", () => {
      const form = buildValidForm({
        level: "k1",
        citizenship: "SPR",
        service: "Half Day",
        home: "654321",
        locationPref: "WORKPLACE",
        work: "112233",
        income: "8500",
        members: "4",
        budget: "1500",
        enrolMonth: "2027-01",
      });
      const apiPayload = toApiProfile(form);
      expect(apiPayload).toMatchObject({
        level: "k1",
        citizenship_status: "SPR",
        service_required: "Half Day",
        home_postal_code: "654321",
        workplace_postal_code: "112233",
        location_preference: "WORKPLACE",
        household_income: 8500,
        household_member_count: 4,
        budget_max: 1500,
        enrollment_month_year: "2027-01",
      });
    });
  });

  describe("fromApiProfile", () => {
    const apiProfile = {
      profile_id: "profile-100",
      profile_name: "Loaded Family Profile",
      level: "pg",
      citizenship_status: "OTHERS",
      service_required: "Full Day",
      home_postal_code: "560123",
      workplace_postal_code: "018989",
      location_preference: "EITHER",
      household_income: 6000,
      household_member_count: 3,
      budget_max: 1200,
      enrollment_month_year: "2027-06",
      vacancy_weight: 2,
      cost_weight: 4,
      travel_weight: 1,
    };

    it("reconstructs frontend form object matching PROFILE_DEFAULTS structure and preserves profile identifiers", () => {
      const reconstructed = fromApiProfile(apiProfile);
      expect(reconstructed.profile_id).toBe("profile-100");
      expect(reconstructed.profile_name).toBe("Loaded Family Profile");
      expect(reconstructed.level).toBe("pg");
      expect(reconstructed.citizenship).toBe("OTHERS");
      expect(reconstructed.service).toBe("Full Day");
      expect(reconstructed.home).toBe("560123");
      expect(reconstructed.work).toBe("018989");
      expect(reconstructed.locationPref).toBe("EITHER");
      expect(reconstructed.income).toBe("6000");
      expect(reconstructed.members).toBe("3");
      expect(reconstructed.budget).toBe(1200);
      expect(reconstructed.enrolMonth).toBe("2027-06");
    });

    it("round-trips backend weights when no local draft exists", () => {
      const reconstructed = fromApiProfile(apiProfile);
      expect(reconstructed.weights).toEqual({ vacancy: 2, cost: 4, travel: 1 });
    });

    it("uses server ratings instead of stale local draft ratings", () => {
      const localDraft = {
        weights: { vacancy: 1, cost: 2, travel: 5 },
      };
      const reconstructed = fromApiProfile(apiProfile, localDraft);
      expect(reconstructed.weights).toEqual({ vacancy: 2, cost: 4, travel: 1 });
    });

    it("rounds server ratings directly and defaults missing ratings", () => {
      const legacyApi = {
        ...apiProfile,
        vacancy_weight: 2.6,
        cost_weight: undefined,
        travel_weight: 5,
      };
      const reconstructed = fromApiProfile(legacyApi);
      expect(reconstructed.weights).toEqual({ vacancy: 3, cost: 3, travel: 5 });
      expect(fromApiProfile({ ...apiProfile, vacancy_weight: 0.35, cost_weight: 0.5, travel_weight: 0.15 }).weights)
        .toEqual({ vacancy: 1, cost: 1, travel: 1 });
    });

    it("converts legacy ranked browser drafts to ratings 3/2/1", () => {
      const legacyDraft = { weights: { vacancy: 50, cost: 35, travel: 15 } };
      const emptyRatings = { ...apiProfile, vacancy_weight: null, cost_weight: null, travel_weight: null };
      expect(fromApiProfile(emptyRatings, legacyDraft).weights).toEqual({ vacancy: 3, cost: 2, travel: 1 });
    });

    it("maps null workplace postal code and zero income to empty strings", () => {
      const minimalApi = {
        ...apiProfile,
        workplace_postal_code: null,
        household_income: 0,
        household_member_count: 1,
      };
      const reconstructed = fromApiProfile(minimalApi);
      expect(reconstructed.work).toBe("");
      expect(reconstructed.income).toBe("");
      expect(reconstructed.members).toBe("1");
    });
  });

  describe("importance defaults and helpers", () => {
    it("exports standard rating keys and labels", () => {
      expect(WEIGHT_KEYS).toEqual(["vacancy", "cost", "travel"]);
      expect(WEIGHT_LABELS).toEqual({
        vacancy: "Vacancy fit",
        cost: "Cost fit",
        travel: "Travel fit",
      });
    });

    it("keeps ties independent and clamps restored ratings to the slider range", () => {
      expect(normalizeWeights({ vacancy: 3, cost: 3, travel: 3 })).toEqual({ vacancy: 3, cost: 3, travel: 3 });
      expect(normalizeWeights({ vacancy: 0, cost: 8, travel: 3 })).toEqual({ vacancy: 1, cost: 5, travel: 3 });
    });

    it("computes nextMonthValue in YYYY-MM format", () => {
      const nextMonth = nextMonthValue();
      expect(nextMonth).toMatch(/^\d{4}-\d{2}$/);
    });
  });
});
