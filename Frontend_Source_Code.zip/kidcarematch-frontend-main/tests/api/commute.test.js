import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { failClosedFetch, jsonResponse } from "../support/fetch.js";

const auth = { currentUser: null };
vi.mock("../../src/firebase", () => ({ auth }));

describe("getCentreCommute API client", () => {
  let fetchMock;
  let api;

  beforeEach(async () => {
    vi.resetModules();
    vi.stubEnv("VITE_API_URL", "https://api.invalid/");
    auth.currentUser = { getIdToken: vi.fn().mockResolvedValue("test-token") };
    fetchMock = failClosedFetch(vi);
    vi.stubGlobal("fetch", fetchMock);
    api = await import("../../src/api.js");
  });

  afterEach(() => {
    expect(fetchMock.unexpectedCalls).toEqual([]);
    vi.unstubAllGlobals();
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  it("posts to centre commute endpoint with encoded ID and default drive mode", async () => {
    const commuteData = {
      centre_id: 101,
      profile_id: "prof-1",
      mode: "drive",
      anchors: {
        home: { lat: 1.3, lng: 103.8 },
        centre: { lat: 1.35, lng: 103.85 },
      },
      samples: [
        {
          kind: "single",
          legs: [
            {
              from_anchor: "home",
              to_anchor: "centre",
              status: "available",
              source: "onemap",
              duration_seconds: 600,
              distance_meters: 5000,
            },
          ],
          totals: { duration_seconds: 600, distance_meters: 5000 },
        },
      ],
    };
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, commuteData));

    const result = await api.getCentreCommute("101/special", {
      profileId: "prof-1",
    });

    expect(result).toEqual(commuteData);
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.invalid/api/v1/centres/101%2Fspecial/commute",
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer test-token",
        }),
        body: JSON.stringify({
          profile_id: "prof-1",
          mode: "drive",
        }),
      })
    );
  });

  it("forwards custom mode, samplePair, and AbortSignal options", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, { status: "ok" }));
    const controller = new AbortController();

    await api.getCentreCommute(
      42,
      {
        profileId: "prof-2",
        mode: "drive",
        samplePair: ["2026-11-11T00:00:00Z", "2026-11-14T00:00:00Z"],
      },
      { signal: controller.signal }
    );

    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.invalid/api/v1/centres/42/commute",
      expect.objectContaining({
        method: "POST",
        signal: controller.signal,
        body: JSON.stringify({
          profile_id: "prof-2",
          mode: "drive",
          sample_pair: ["2026-11-11T00:00:00Z", "2026-11-14T00:00:00Z"],
        }),
      })
    );
  });

  it("negotiates commute capabilities without changing legacy requests", async () => {
    const capabilities = {
      direct_baseline_contract: "direct_baseline_v1",
      sampling_contract: null,
    };
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, capabilities));

    await expect(api.getCommuteCapabilities()).resolves.toEqual(capabilities);
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.invalid/api/v1/commute/capabilities",
      expect.objectContaining({ method: "GET" })
    );
  });

  it("opts into a direct baseline only when explicitly requested", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, { mode: "drive" }));

    await api.getCentreCommute(101, {
      profileId: "prof-1",
      includeDirectBaseline: true,
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.invalid/api/v1/centres/101/commute",
      expect.objectContaining({
        body: JSON.stringify({
          profile_id: "prof-1",
          mode: "drive",
          include_direct_baseline: true,
        }),
      })
    );
  });

  it("keeps the legacy public-transport sample pair when opting into the baseline only", async () => {
    const samplePair = ["2026-11-11T08:00:00+08:00", "2026-11-14T08:00:00+08:00"];
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, { mode: "pt" }));

    await api.getCentreCommute(101, {
      profileId: "prof-1", mode: "pt", samplePair, includeDirectBaseline: true,
    });

    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.invalid/api/v1/centres/101/commute",
      expect.objectContaining({
        body: JSON.stringify({
          profile_id: "prof-1", mode: "pt", sample_pair: samplePair,
          include_direct_baseline: true,
        }),
      })
    );
  });

  it("supports walking and cycling mode payloads", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, { mode: "walk" }));
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, { mode: "cycle" }));

    await api.getCentreCommute(101, { profileId: "prof-1", mode: "walk" });
    expect(fetchMock).toHaveBeenNthCalledWith(
      1,
      "https://api.invalid/api/v1/centres/101/commute",
      expect.objectContaining({
        body: JSON.stringify({
          profile_id: "prof-1",
          mode: "walk",
        }),
      })
    );

    await api.getCentreCommute(101, { profileId: "prof-1", mode: "cycle" });
    expect(fetchMock).toHaveBeenNthCalledWith(
      2,
      "https://api.invalid/api/v1/centres/101/commute",
      expect.objectContaining({
        body: JSON.stringify({
          profile_id: "prof-1",
          mode: "cycle",
        }),
      })
    );
  });

  it("sends selected sampling opt-in without changing legacy request bodies", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, { sampling_contract: "weekday_0800_wed_thu_fri_v1" }));
    await api.getCentreCommute(101, {
      profileId: "prof-1", mode: "pt", sampling: {
        policy: "weekday_0800_wed_thu_fri_v1", cycle_id: "cycle-a", sample_index: 1,
      },
    });
    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toEqual({
      profile_id: "prof-1", mode: "pt", sampling: {
        policy: "weekday_0800_wed_thu_fri_v1", cycle_id: "cycle-a", sample_index: 1,
      },
    });
  });

  it("sends the independent baseline and selected-sampling opt-ins together without a legacy pair", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, {
      comparison_contract: "direct_baseline_v1",
      sampling_contract: "weekday_0800_wed_thu_fri_v1",
    }));
    await api.getCentreCommute(101, {
      profileId: "prof-1", mode: "pt", includeDirectBaseline: true,
      sampling: { policy: "weekday_0800_wed_thu_fri_v1", cycle_id: null, sample_index: 0 },
    });

    expect(JSON.parse(fetchMock.mock.calls[0][1].body)).toEqual({
      profile_id: "prof-1",
      mode: "pt",
      include_direct_baseline: true,
      sampling: { policy: "weekday_0800_wed_thu_fri_v1", cycle_id: null, sample_index: 0 },
    });
  });

  it("rejects contradictory or malformed selected sampling before making a request", async () => {
    const sampling = { policy: "weekday_0800_wed_thu_fri_v1", cycle_id: null, sample_index: 0 };
    expect(() => api.getCentreCommute(101, { profileId: "prof-1", mode: "drive", sampling })).toThrow(/only valid for public transport/);
    expect(() => api.getCentreCommute(101, { profileId: "prof-1", mode: "pt", samplePair: ["wed", "sat"], sampling })).toThrow(/cannot be combined/);
    expect(() => api.getCentreCommute(101, { profileId: "prof-1", mode: "pt", sampling: { ...sampling, sample_index: 1 } })).toThrow(/Invalid selected weekday/);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("discovers independent commute capabilities", async () => {
    const capabilities = { direct_baseline_contract: null, sampling_contract: "weekday_0800_wed_thu_fri_v1" };
    fetchMock.mockResolvedValueOnce(jsonResponse(vi, capabilities));
    await expect(api.getCommuteCapabilities()).resolves.toEqual(capabilities);
    expect(fetchMock).toHaveBeenCalledWith(
      "https://api.invalid/api/v1/commute/capabilities",
      expect.objectContaining({ headers: expect.objectContaining({ Authorization: "Bearer test-token" }) })
    );
  });

  it("rejects on HTTP error response", async () => {
    fetchMock.mockResolvedValueOnce(
      jsonResponse(vi, { detail: "Preference profile not found" }, 404)
    );

    await expect(
      api.getCentreCommute(101, { profileId: "prof-nonexistent" })
    ).rejects.toThrow("404: Preference profile not found");
  });
});
